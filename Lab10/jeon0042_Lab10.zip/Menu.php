<?php
	echo "<div id=\"menu\">";
	echo "<h2>Menu</h2>";
	echo "<h3>Links to Labs and Lab10</h3><br />";
	echo '<a href="http://149.56.204.160/~oceanpla/CST8238/Lab10/Books.php">Books.php</a>',"<br/>";
	echo '<a href="http://149.56.204.160/~oceanpla/CST8238/Lab10/Employee.php">Employee.php</a>',"<br/>";
	echo "</div>";
?>
