<?php
	echo "<div id=\"footer\">";
	echo "Student Number: 040885882 <br />
			First Name: Seongyeop <br />
			Last Name: Jeong <br />
			Email address: jeon0042@algonquinlive.com";
	echo "</div>";
?>