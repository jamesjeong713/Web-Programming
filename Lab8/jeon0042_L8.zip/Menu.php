<?php
	echo "<div id=\"menu\">";
	echo "<h2>Menu</h2>";
	echo "<h3>Links to Labs and Lab8</h3><br />";
	echo '<a href="http://149.56.204.160/~oceanpla/CST8238/Lab8/Input.php">Input.php</a>',"<br/>";
	echo '<a href="http://149.56.204.160/~oceanpla/CST8238/Lab8/Session1.php">Session1.php</a>',"<br/>";
	echo '<a href="http://149.56.204.160/~oceanpla/CST8238/Lab8/Session2.php">Session2.php</a>',"<br/>";	
	echo "</div>";
?>
