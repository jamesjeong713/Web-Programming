<?php
echo "<div id=\"header\">";
echo "<h1>Welcome to Lab 9</h1>";
echo "<img src='images.png'>";
echo "</div>";
?>
